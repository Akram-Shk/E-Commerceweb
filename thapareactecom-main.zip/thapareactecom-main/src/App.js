import React from "react";

const App = () => {
  return <div>Welcome to Thapa React E-Commerce Website</div>;
};

export default App;
